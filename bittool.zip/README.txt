Gilbert Grundy
Homework 1

To be completely honest, I found this a much more challenging assignment
than I initially thought. Your code made zero sense to me, and I wasn't sure
where to begin. So I started to just play around with C in general, even made
a Hello World program to start to get to grips with the printf function!

I slowly started to incorporate your code into the program, as I began to
understand what it did! Some of the lectures began to come back to me, and
before I knew it I was actually writing useful code!

The program functions as you requested; with two arguments it prints the
the position of the two numbers common bitset positions, and the number
the bitsets represent in unsigned hex, signed decimal, and unsigned decimal.
While if the program is given over two arguments, it prints a binary number,
with ones representing the arguments as bit positions. The program also
successfuly prints an error message if the input does not meet the required
criteria.

After this homework I feel a lot more comfortablewith bitwise operators, 
command line arguments, C, and Makefiles. The struggle was worth it!
